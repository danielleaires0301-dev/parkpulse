# ParkPulse 🎢

Live Disney World wait times with custom ride alerts.

## Setup & Deploy (5 minutes)

### 1. Install Node.js
Download from https://nodejs.org (pick LTS version)

### 2. Install dependencies
```
npm install
```

### 3. Run locally to test
```
npm run dev
```
Open http://localhost:5173 in your browser

### 4. Deploy to Vercel (free)
1. Go to https://vercel.com and sign up with GitHub
2. Install Vercel CLI: `npm install -g vercel`
3. Run: `vercel`
4. Follow the prompts — your app will be live at a .vercel.app URL!

### 5. Install on your iPhone as a PWA
1. Open your Vercel URL in Safari
2. Tap the Share button (box with arrow)
3. Tap "Add to Home Screen"
4. Tap "Add" — ParkPulse is now on your home screen like a native app!

## Features
- Live wait times from all 4 Walt Disney World parks
- Per-ride alert thresholds (tap "+ alert" on any ride)
- Browser/push notifications when wait drops below your threshold
- Auto-refresh every 60 seconds
- Search and filter rides
- Thresholds saved locally (persist between sessions)
- PWA — installable on iPhone/Android

## Data Source
ThemeParks.wiki API (free, no key required)

## Next Steps
- Add user accounts (Supabase)
- Server-side push notifications (Firebase FCM)
- Wait time history charts
- Disneyland + international parks
