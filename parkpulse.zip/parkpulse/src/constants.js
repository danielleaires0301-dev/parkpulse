export const PARKS = [
  { id: "75ea578a-adc8-4116-a54d-dccb60765ef0", name: "Magic Kingdom",     emoji: "🏰", color: "#4A90D9" },
  { id: "47f90d2c-e191-4239-a466-5892ef59a88b", name: "EPCOT",             emoji: "🌐", color: "#00B4D8" },
  { id: "288747d1-8b4f-4a64-867e-ea7c9b27bad8", name: "Hollywood Studios", emoji: "🎬", color: "#E63946" },
  { id: "1c84a229-8862-4648-9c71-378ddd2c7693", name: "Animal Kingdom",    emoji: "🦁", color: "#2D6A4F" },
];

export const REFRESH_INTERVAL = 60 * 1000; // 60 seconds
