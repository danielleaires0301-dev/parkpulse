import { useState, useEffect } from "react";
import { PARKS } from "./constants";
import ParkPanel from "./components/ParkPanel";
import Header from "./components/Header";
import ParkTabs from "./components/ParkTabs";

export default function App() {
  const [activePark, setActivePark] = useState(PARKS[0]);
  const [thresholds, setThresholds] = useState(() => {
    try { return JSON.parse(localStorage.getItem("pp_thresholds") || "{}"); }
    catch { return {}; }
  });
  const [notifGranted, setNotifGranted] = useState(
    typeof Notification !== "undefined" && Notification.permission === "granted"
  );

  useEffect(() => {
    localStorage.setItem("pp_thresholds", JSON.stringify(thresholds));
  }, [thresholds]);

  const requestNotif = async () => {
    if (!("Notification" in window)) return alert("Notifications not supported in this browser.");
    const perm = await Notification.requestPermission();
    setNotifGranted(perm === "granted");
  };

  const setThreshold = (rideId, val) =>
    setThresholds(prev => ({ ...prev, [rideId]: val }));

  return (
    <div style={{
      minHeight: "100dvh", background: "#080812",
      backgroundImage: "radial-gradient(ellipse at 20% 10%, #1a1a3e 0%, transparent 60%), radial-gradient(ellipse at 80% 80%, #0d1f3c 0%, transparent 50%)",
      fontFamily: "'Outfit', sans-serif", color: "#f0f0f0",
      display: "flex", flexDirection: "column",
    }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=DM+Mono:wght@400;500;600&display=swap');`}</style>
      <Header notifGranted={notifGranted} onRequestNotif={requestNotif} />
      <ParkTabs parks={PARKS} activePark={activePark} onSelect={setActivePark} />
      <div style={{ flex: 1, overflow: "hidden", animation: "fadeIn 0.3s ease" }} key={activePark.id}>
        <ParkPanel park={activePark} thresholds={thresholds} onThresholdChange={setThreshold} />
      </div>
      <footer style={{ padding: "8px 20px", borderTop: "1px solid #ffffff08", fontSize: 10, color: "#444", display: "flex", justifyContent: "space-between" }}>
        <span>Data: ThemeParks.wiki API · Refreshes every 60s</span>
        <span>ParkPulse v0.2</span>
      </footer>
    </div>
  );
}
