const BASE = "https://api.themeparks.wiki/v1";

export async function fetchParkWaitTimes(parkId) {
  const res = await fetch(`${BASE}/entity/${parkId}/live`);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  const data = await res.json();
  return (data.liveData || [])
    .filter(r => r.entityType === "ATTRACTION")
    .map(r => ({
      id: r.id,
      name: r.name,
      status: r.status,
      waitTime: r.queue?.STANDBY?.waitTime ?? null,
    }))
    .sort((a, b) => {
      if (a.waitTime === null && b.waitTime === null) return a.name.localeCompare(b.name);
      if (a.waitTime === null) return 1;
      if (b.waitTime === null) return -1;
      return b.waitTime - a.waitTime;
    });
}
