import { useState, useEffect, useCallback, useRef } from "react";
import { fetchParkWaitTimes } from "./api";
import { REFRESH_INTERVAL } from "./constants";

export function useWaitTimes(parkId) {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchParkWaitTimes(parkId);
      setRides(data);
      setLastUpdated(new Date());
    } catch (e) {
      setError(e.message || "Failed to load wait times");
    } finally {
      setLoading(false);
    }
  }, [parkId]);

  useEffect(() => {
    load();
    const interval = setInterval(load, REFRESH_INTERVAL);
    return () => clearInterval(interval);
  }, [load]);

  return { rides, loading, error, lastUpdated, refresh: load };
}

export function useNotifications(rides, thresholds) {
  const fired = useRef(new Set());

  useEffect(() => {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    rides.forEach(ride => {
      const t = thresholds[ride.id];
      if (t != null && ride.waitTime !== null && ride.waitTime <= t) {
        const key = `${ride.id}:${ride.waitTime}`;
        if (!fired.current.has(key)) {
          fired.current.add(key);
          new Notification(`🎢 ${ride.name} — ${ride.waitTime} min wait!`, {
            body: `Wait dropped to ${ride.waitTime} min (your alert: ${t} min)`,
            icon: "/icon-192.png",
            badge: "/icon-192.png",
          });
        }
      }
    });
  }, [rides, thresholds]);
}
