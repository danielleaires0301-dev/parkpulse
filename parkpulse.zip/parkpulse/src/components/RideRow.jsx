import { useState } from "react";

function WaitBadge({ minutes, threshold }) {
  const isAlert = threshold !== null && minutes !== null && minutes <= threshold;
  const color =
    minutes === null ? "#6b7280"
    : minutes <= 15 ? "#22c55e"
    : minutes <= 30 ? "#84cc16"
    : minutes <= 60 ? "#f59e0b"
    : "#ef4444";

  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 6, flexShrink: 0,
      background: isAlert ? `${color}20` : "#ffffff08",
      border: `1.5px solid ${isAlert ? color : "#ffffff15"}`,
      borderRadius: 8, padding: "5px 10px",
      animation: isAlert ? "pulse 1.5s infinite" : "none",
    }}>
      <div style={{ width: 8, height: 8, borderRadius: "50%", background: color, flexShrink: 0 }} />
      <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 13, color: minutes === null ? "#6b7280" : "#f0f0f0", fontWeight: 600 }}>
        {minutes === null ? "N/A" : `${minutes}m`}
      </span>
      {isAlert && <span style={{ fontSize: 9, color, fontWeight: 800, letterSpacing: "0.5px" }}>ALERT</span>}
    </div>
  );
}

export default function RideRow({ ride, threshold, onThresholdChange }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(threshold !== null ? String(threshold) : "");

  const save = () => {
    const n = parseInt(val);
    onThresholdChange(ride.id, isNaN(n) ? null : n);
    setEditing(false);
  };

  const clear = () => {
    onThresholdChange(ride.id, null);
    setVal("");
    setEditing(false);
  };

  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "10px 12px", borderRadius: 10, marginBottom: 4,
      background: "#ffffff07", border: "1px solid #ffffff0a",
      transition: "background 0.15s",
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, color: "#e0e0e0", fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {ride.name}
        </div>
        <div style={{ fontSize: 11, color: "#555", marginTop: 2 }}>
          {ride.status === "OPERATING" ? "🟢 Open"
          : ride.status === "DOWN" ? "🔴 Down"
          : ride.status === "CLOSED" ? "⚫ Closed"
          : "🟡 Refurb"}
        </div>
      </div>

      <WaitBadge minutes={ride.waitTime} threshold={threshold} />

      <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
        {editing ? (
          <>
            <input
              autoFocus value={val} onChange={e => setVal(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter") save(); if (e.key === "Escape") setEditing(false); }}
              placeholder="min" type="number"
              style={{ width: 48, padding: "4px 6px", borderRadius: 6, border: "1px solid #4A90D9", background: "#0d0d1a", color: "#fff", fontSize: 12, outline: "none", fontFamily: "'DM Mono', monospace" }}
            />
            <button onClick={save} style={{ background: "#4A90D9", color: "#fff", border: "none", borderRadius: 6, padding: "4px 8px", cursor: "pointer", fontSize: 11 }}>✓</button>
            {threshold !== null && (
              <button onClick={clear} style={{ background: "#ef444422", color: "#ef4444", border: "1px solid #ef444444", borderRadius: 6, padding: "4px 6px", cursor: "pointer", fontSize: 11 }}>✕</button>
            )}
          </>
        ) : (
          <button onClick={() => { setVal(threshold !== null ? String(threshold) : ""); setEditing(true); }} style={{
            background: threshold !== null ? "#4A90D922" : "#ffffff0a",
            color: threshold !== null ? "#4A90D9" : "#555",
            border: `1px solid ${threshold !== null ? "#4A90D944" : "#ffffff12"}`,
            borderRadius: 6, padding: "4px 9px", cursor: "pointer", fontSize: 11,
            fontFamily: "'DM Mono', monospace",
          }}>
            {threshold !== null ? `≤${threshold}m` : "+ alert"}
          </button>
        )}
      </div>
    </div>
  );
}
