export default function Header({ notifGranted, onRequestNotif }) {
  return (
    <header style={{
      padding: "16px 20px 12px", borderBottom: "1px solid #ffffff10",
      display: "flex", alignItems: "center", justifyContent: "space-between",
      background: "#080812dd", position: "sticky", top: 0, zIndex: 10,
      backdropFilter: "blur(12px)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ fontSize: 26 }}>🎢</span>
        <div>
          <div style={{ fontSize: 20, fontWeight: 800, letterSpacing: "-0.5px", background: "linear-gradient(90deg, #4A90D9, #00B4D8)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            ParkPulse
          </div>
          <div style={{ fontSize: 10, color: "#6b7280", marginTop: -2 }}>Live Disney Wait Times</div>
        </div>
      </div>
      {!notifGranted ? (
        <button onClick={onRequestNotif} style={{
          background: "linear-gradient(135deg, #4A90D9, #00B4D8)", border: "none",
          borderRadius: 10, padding: "8px 14px", color: "#fff",
          cursor: "pointer", fontSize: 12, fontWeight: 600,
          boxShadow: "0 4px 15px #4A90D944",
        }}>🔔 Enable Alerts</button>
      ) : (
        <div style={{ fontSize: 11, color: "#22c55e", display: "flex", alignItems: "center", gap: 5 }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#22c55e", boxShadow: "0 0 6px #22c55e" }} />
          Alerts active
        </div>
      )}
    </header>
  );
}
