export default function ParkTabs({ parks, activePark, onSelect }) {
  return (
    <div style={{ display: "flex", borderBottom: "1px solid #ffffff10", padding: "0 12px", overflowX: "auto", scrollbarWidth: "none" }}>
      {parks.map(p => (
        <button key={p.id} onClick={() => onSelect(p)} style={{
          padding: "12px 16px", background: "none", border: "none",
          borderBottom: `2px solid ${activePark.id === p.id ? p.color : "transparent"}`,
          color: activePark.id === p.id ? p.color : "#6b7280",
          cursor: "pointer", fontSize: 13,
          fontWeight: activePark.id === p.id ? 700 : 400,
          fontFamily: "'Outfit', sans-serif",
          transition: "all 0.2s", whiteSpace: "nowrap",
        }}>
          {p.emoji} {p.name.split(" ")[0]}
        </button>
      ))}
    </div>
  );
}
