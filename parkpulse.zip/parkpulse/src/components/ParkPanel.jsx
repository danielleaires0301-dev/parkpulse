import { useState } from "react";
import { useWaitTimes, useNotifications } from "../useWaitTimes";
import RideRow from "./RideRow";

export default function ParkPanel({ park, thresholds, onThresholdChange }) {
  const { rides, loading, error, lastUpdated, refresh } = useWaitTimes(park.id);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  useNotifications(rides, thresholds);

  const alertCount = rides.filter(r =>
    thresholds[r.id] != null && r.waitTime !== null && r.waitTime <= thresholds[r.id]
  ).length;

  const filtered = rides.filter(r => {
    const matchSearch = r.name.toLowerCase().includes(search.toLowerCase());
    const matchFilter =
      filter === "operating" ? r.status === "OPERATING" :
      filter === "alert" ? (thresholds[r.id] != null && r.waitTime !== null && r.waitTime <= thresholds[r.id]) :
      true;
    return matchSearch && matchFilter;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {/* Panel header */}
      <div style={{ padding: "14px 16px 10px", borderBottom: "1px solid #ffffff10" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 22 }}>{park.emoji}</span>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: "#f0f0f0" }}>{park.name}</div>
              <div style={{ fontSize: 11, color: "#6b7280" }}>
                {loading ? "Fetching..." : lastUpdated ? `Updated ${lastUpdated.toLocaleTimeString()}` : ""}
              </div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {alertCount > 0 && (
              <div style={{ background: "#ef444422", border: "1px solid #ef4444", borderRadius: 20, padding: "2px 10px", fontSize: 11, color: "#ef4444", fontWeight: 700, animation: "pulse 2s infinite" }}>
                🔔 {alertCount} alert{alertCount !== 1 ? "s" : ""}
              </div>
            )}
            <button onClick={refresh} disabled={loading} style={{
              background: "#ffffff0a", border: "1px solid #ffffff15", borderRadius: 8,
              padding: "5px 12px", color: "#aaa", cursor: "pointer", fontSize: 11,
              opacity: loading ? 0.4 : 1,
            }}>
              {loading ? "⏳" : "↻ Refresh"}
            </button>
          </div>
        </div>

        {/* Search + filters */}
        <div style={{ display: "flex", gap: 6, marginTop: 10 }}>
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search rides..."
            style={{ flex: 1, padding: "6px 10px", borderRadius: 8, border: "1px solid #ffffff15", background: "#ffffff08", color: "#e0e0e0", fontSize: 12, outline: "none", fontFamily: "inherit" }}
          />
          {["all", "operating", "alert"].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{
              padding: "5px 10px", borderRadius: 8, fontSize: 11, cursor: "pointer",
              background: filter === f ? park.color + "33" : "#ffffff08",
              color: filter === f ? park.color : "#6b7280",
              border: `1px solid ${filter === f ? park.color + "66" : "#ffffff15"}`,
              fontFamily: "inherit",
            }}>
              {f === "all" ? "All" : f === "operating" ? "Open" : "🔔"}
            </button>
          ))}
        </div>
      </div>

      {/* Ride list */}
      <div style={{ flex: 1, overflowY: "auto", padding: "8px 12px 20px" }}>
        {loading && (
          <div style={{ textAlign: "center", padding: "60px 20px", color: "#6b7280" }}>
            <div style={{ fontSize: 36, marginBottom: 16 }}>⏳</div>
            <div style={{ fontSize: 14, marginBottom: 6 }}>Fetching live wait times...</div>
            <div style={{ fontSize: 11, color: "#444" }}>Auto-refreshes every 60 seconds</div>
          </div>
        )}
        {error && !loading && (
          <div style={{ textAlign: "center", padding: "60px 20px" }}>
            <div style={{ fontSize: 36, marginBottom: 16 }}>⚠️</div>
            <div style={{ fontSize: 13, color: "#ef4444", marginBottom: 20 }}>{error}</div>
            <button onClick={refresh} style={{ background: "#4A90D9", color: "#fff", border: "none", borderRadius: 10, padding: "10px 24px", cursor: "pointer", fontSize: 13, fontFamily: "inherit" }}>
              Try Again
            </button>
          </div>
        )}
        {!loading && !error && filtered.length === 0 && (
          <div style={{ textAlign: "center", padding: "60px 20px", color: "#6b7280", fontSize: 13 }}>
            No rides match your filter.
          </div>
        )}
        {!loading && !error && filtered.map(ride => (
          <RideRow
            key={ride.id} ride={ride}
            threshold={thresholds[ride.id] ?? null}
            onThresholdChange={onThresholdChange}
          />
        ))}
      </div>
    </div>
  );
}
